import { 
  Globe, 
  Smartphone, 
  Palette, 
  Target, 
  TrendingUp, 
  Cloud 
} from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Globe,
      title: 'Web Development',
      description: 'Custom websites and web applications built with modern technologies for optimal performance and user experience.',
      features: ['Responsive Design', 'Performance Optimization', 'SEO Friendly', 'Modern Frameworks'],
    },
    {
      icon: Smartphone,
      title: 'Mobile App Development',
      description: 'Native and cross-platform mobile applications that deliver exceptional user experiences across all devices.',
      features: ['iOS & Android', 'Cross-Platform', 'UI/UX Design', 'App Store Optimization'],
    },
    {
      icon: Palette,
      title: 'UI/UX Design',
      description: 'User-centered design solutions that create intuitive and engaging digital experiences for your customers.',
      features: ['User Research', 'Wireframing', 'Prototyping', 'Design Systems'],
    },
    {
      icon: Target,
      title: 'Branding & Identity',
      description: 'Complete brand identity solutions including logo design, brand guidelines, and marketing materials.',
      features: ['Logo Design', 'Brand Guidelines', 'Marketing Materials', 'Brand Strategy'],
    },
    {
      icon: TrendingUp,
      title: 'Digital Marketing',
      description: 'Comprehensive digital marketing strategies to increase your online presence and drive business growth.',
      features: ['SEO/SEM', 'Social Media', 'Content Marketing', 'Analytics'],
    },
    {
      icon: Cloud,
      title: 'Cloud Hosting Solutions',
      description: 'Reliable and scalable cloud hosting services with 24/7 support and optimal performance guarantees.',
      features: ['99.9% Uptime', '24/7 Support', 'Scalable Infrastructure', 'Security Monitoring'],
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-heading text-5xl font-bold text-gray-900 mb-6">
            Our Services
          </h1>
          <p className="font-body text-xl text-gray-600 max-w-3xl mx-auto">
            We offer comprehensive digital solutions to help your business thrive in the modern world. 
            From web development to digital marketing, we have the expertise to bring your vision to life.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div
                  key={service.title}
                  className="card-elevated bg-white p-8 rounded-2xl hover-lift animate-fade-in-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="w-16 h-16 bg-gradient-primary rounded-2xl mb-6 flex items-center justify-center">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <h3 className="font-heading text-2xl font-semibold text-gray-900 mb-4">
                    {service.title}
                  </h3>
                  
                  <p className="font-body text-gray-600 mb-6 leading-relaxed">
                    {service.description}
                  </p>
                  
                  <ul className="space-y-2">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-center font-body text-sm text-gray-500">
                        <div className="w-2 h-2 bg-gradient-primary rounded-full mr-3"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-gray-900 mb-4">
              Our Process
            </h2>
            <p className="font-body text-xl text-gray-600 max-w-2xl mx-auto">
              We follow a proven methodology to ensure every project delivers exceptional results.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                step: '01',
                title: 'Discovery',
                description: 'We start by understanding your business goals, target audience, and project requirements.',
              },
              {
                step: '02',
                title: 'Strategy',
                description: 'Our team develops a comprehensive strategy and roadmap tailored to your specific needs.',
              },
              {
                step: '03',
                title: 'Development',
                description: 'We bring your vision to life using cutting-edge technologies and best practices.',
              },
              {
                step: '04',
                title: 'Launch',
                description: 'We deploy your solution and provide ongoing support to ensure continued success.',
              },
            ].map((process, index) => (
              <div
                key={process.step}
                className="text-center animate-fade-in-up"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="w-16 h-16 bg-gradient-primary rounded-full mx-auto mb-6 flex items-center justify-center">
                  <span className="font-heading font-bold text-white text-lg">
                    {process.step}
                  </span>
                </div>
                <h3 className="font-heading text-xl font-semibold text-gray-900 mb-4">
                  {process.title}
                </h3>
                <p className="font-body text-gray-600">
                  {process.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-heading text-4xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="font-body text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Let's discuss your project and explore how we can help bring your digital vision to life.
          </p>
          <button className="bg-white text-primary font-medium px-8 py-4 rounded-xl hover:bg-gray-50 transition-colors font-body text-lg hover-lift">
            Start Your Project
          </button>
        </div>
      </section>
    </div>
  );
};

export default Services;