import teamSarah from '@/assets/team-sarah.jpg';
import teamAhmed from '@/assets/team-ahmed.jpg';
import teamEmily from '@/assets/team-emily.jpg';

const About = () => {
  const team = [
    {
      name: 'Sarah Johnson',
      role: 'CEO & Founder',
      image: teamSarah,
      description: 'Visionary leader with 15+ years in tech industry, driving innovation and growth.',
    },
    {
      name: 'Ahmed Khan',
      role: 'Lead Developer',
      image: teamAhmed,
      description: 'Full-stack expert specializing in modern web technologies and scalable solutions.',
    },
    {
      name: 'Emily Carter',
      role: 'Marketing Manager',
      image: teamEmily,
      description: 'Creative strategist focused on digital marketing and brand development.',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-heading text-5xl font-bold text-gray-900 mb-6">
            Who We Are
          </h1>
          <div className="max-w-4xl mx-auto">
            <p className="font-body text-xl text-gray-600 leading-relaxed">
              At DevTech Solutions, we are passionate about helping companies transform digitally. 
              With expertise in web development, mobile apps, and branding, we empower businesses 
              to stand out in a competitive world.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="card-elevated bg-white p-8 rounded-2xl">
              <h2 className="font-heading text-3xl font-bold text-gray-900 mb-6">
                Our Mission
              </h2>
              <p className="font-body text-lg text-gray-600 leading-relaxed">
                To empower businesses with cutting-edge digital solutions that drive growth, 
                enhance user experiences, and create lasting value. We believe in the power 
                of technology to transform ideas into reality.
              </p>
            </div>
            <div className="card-elevated bg-white p-8 rounded-2xl">
              <h2 className="font-heading text-3xl font-bold text-gray-900 mb-6">
                Our Vision
              </h2>
              <p className="font-body text-lg text-gray-600 leading-relaxed">
                To be the leading digital transformation partner for businesses worldwide, 
                known for innovation, quality, and exceptional client relationships. We envision 
                a future where technology seamlessly serves human needs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-gray-900 mb-4">
              Meet Our Team
            </h2>
            <p className="font-body text-xl text-gray-600 max-w-2xl mx-auto">
              Our talented team of professionals brings diverse expertise and shared passion 
              for creating exceptional digital experiences.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div
                key={member.name}
                className="card-elevated bg-white rounded-2xl overflow-hidden animate-fade-in-up"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="aspect-square overflow-hidden">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <h3 className="font-heading text-xl font-semibold text-gray-900 mb-2">
                    {member.name}
                  </h3>
                  <p className="text-gradient font-medium mb-3">
                    {member.role}
                  </p>
                  <p className="font-body text-gray-600">
                    {member.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-gray-900 mb-4">
              Our Values
            </h2>
            <p className="font-body text-xl text-gray-600 max-w-2xl mx-auto">
              The principles that guide everything we do.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Innovation',
                description: 'We stay ahead of technology trends to deliver cutting-edge solutions.',
              },
              {
                title: 'Quality',
                description: 'Excellence is not an option—it\'s our standard for every project.',
              },
              {
                title: 'Partnership',
                description: 'We build lasting relationships based on trust and mutual success.',
              },
            ].map((value, index) => (
              <div
                key={value.title}
                className="text-center p-6 animate-fade-in-up"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="w-16 h-16 bg-gradient-primary rounded-2xl mx-auto mb-6 flex items-center justify-center text-2xl font-bold text-white">
                  {value.title[0]}
                </div>
                <h3 className="font-heading text-xl font-semibold text-gray-900 mb-4">
                  {value.title}
                </h3>
                <p className="font-body text-gray-600">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;