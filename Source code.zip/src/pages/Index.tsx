import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import heroImage from '@/assets/hero-image.jpg';

const Index = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      text: "Working with DevTech was a game changer for our business!",
      author: "Michael Smith",
      company: "BrightWave Agency",
    },
    {
      text: "Professional team, great communication, and stunning results.",
      author: "Anna Lee",
      company: "GlobalMart",
    },
    {
      text: "They delivered our project on time with amazing quality.",
      author: "David Johnson",
      company: "HealthFirst Clinics",
    },
  ];

  const clients = [
    'BrightWave Agency',
    'GlobalMart',
    'HealthFirst Clinics',
    'NextGen Finance',
    'UrbanFoods',
  ];

  const services = [
    {
      title: 'Web Development',
      description: 'Custom websites and web applications built with modern technologies.',
    },
    {
      title: 'Mobile App Development',
      description: 'Native and cross-platform mobile applications for all devices.',
    },
    {
      title: 'UI/UX Design',
      description: 'User-centered design solutions that create engaging experiences.',
    },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero"></div>
        <div className="absolute inset-0 bg-black/30"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat mix-blend-overlay"
          style={{ backgroundImage: `url(${heroImage})` }}
        ></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-heading text-5xl lg:text-7xl font-bold text-white mb-6 animate-fade-in-up">
              Building Digital Solutions <br />
              <span className="text-gradient bg-gradient-to-r from-blue-200 to-purple-200 bg-clip-text text-transparent">
                That Drive Success
              </span>
            </h1>
            <p className="font-body text-xl lg:text-2xl text-white/90 mb-8 max-w-3xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
              We help businesses grow with modern websites, apps, and strategies.
            </p>
            <Button 
              className="btn-gradient text-white font-medium px-8 py-4 text-lg animate-fade-in-up hover-lift"
              style={{ animationDelay: '0.4s' }}
            >
              Get Started
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* About Preview Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in-up">
              <h2 className="font-heading text-4xl font-bold text-gray-900 mb-6">
                Who We Are
              </h2>
              <p className="font-body text-lg text-gray-600 mb-8 leading-relaxed">
                At DevTech Solutions, we are passionate about helping companies transform digitally. 
                With expertise in web development, mobile apps, and branding, we empower businesses 
                to stand out in a competitive world.
              </p>
              <Link to="/about">
                <Button variant="outline" className="border-2 border-primary text-primary hover:bg-primary hover:text-white">
                  Learn More About Us
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
            </div>
            <div className="animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-gradient-primary p-6 rounded-2xl text-white">
                  <div className="text-3xl font-bold mb-2">150+</div>
                  <div className="text-white/90">Projects Completed</div>
                </div>
                <div className="bg-white border-2 border-primary p-6 rounded-2xl">
                  <div className="text-3xl font-bold text-primary mb-2">98%</div>
                  <div className="text-gray-600">Client Satisfaction</div>
                </div>
                <div className="bg-white border-2 border-secondary p-6 rounded-2xl">
                  <div className="text-3xl font-bold text-secondary mb-2">5+</div>
                  <div className="text-gray-600">Years Experience</div>
                </div>
                <div className="bg-gradient-to-br from-secondary to-primary p-6 rounded-2xl text-white">
                  <div className="text-3xl font-bold mb-2">24/7</div>
                  <div className="text-white/90">Support</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-gray-900 mb-4">
              Our Services
            </h2>
            <p className="font-body text-xl text-gray-600 max-w-2xl mx-auto">
              We offer comprehensive digital solutions to help your business thrive in the modern world.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {services.map((service, index) => (
              <div
                key={service.title}
                className="bg-white p-8 rounded-2xl card-elevated hover-lift animate-fade-in-up"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <h3 className="font-heading text-xl font-semibold text-gray-900 mb-4">
                  {service.title}
                </h3>
                <p className="font-body text-gray-600 mb-6">
                  {service.description}
                </p>
                <div className="w-12 h-1 bg-gradient-primary rounded-full"></div>
              </div>
            ))}
          </div>

          <div className="text-center">
            <Link to="/services">
              <Button className="btn-gradient text-white font-medium px-8 py-3">
                View All Services
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Clients Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-gray-900 mb-4">
              Trusted By
            </h2>
            <p className="font-body text-xl text-gray-600">
              Leading companies choose us for their digital transformation
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
            {clients.map((client, index) => (
              <div
                key={client}
                className="bg-gray-50 p-6 rounded-xl flex items-center justify-center hover:bg-primary/5 transition-colors hover-lift animate-fade-in-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <span className="font-body font-medium text-gray-700 text-center">
                  {client}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gradient-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-white mb-4">
              What Our Clients Say
            </h2>
            <p className="font-body text-xl text-white/90">
              Don't just take our word for it - hear from satisfied clients
            </p>
          </div>

          <div className="relative max-w-4xl mx-auto">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 md:p-12 text-center">
              <div className="flex justify-center mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <blockquote className="font-body text-2xl text-white mb-8 italic">
                "{testimonials[currentTestimonial].text}"
              </blockquote>
              
              <div className="text-white">
                <div className="font-heading font-semibold text-lg">
                  {testimonials[currentTestimonial].author}
                </div>
                <div className="font-body text-white/80">
                  {testimonials[currentTestimonial].company}
                </div>
              </div>
            </div>

            {/* Navigation */}
            <button
              onClick={prevTestimonial}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <ChevronLeft className="w-6 h-6 text-white" />
            </button>
            <button
              onClick={nextTestimonial}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <ChevronRight className="w-6 h-6 text-white" />
            </button>

            {/* Dots */}
            <div className="flex justify-center space-x-2 mt-8">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentTestimonial ? 'bg-white' : 'bg-white/50'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-heading text-4xl font-bold text-gray-900 mb-6">
            Ready to Get Started?
          </h2>
          <p className="font-body text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Let's discuss your project and explore how we can help bring your digital vision to life.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/contact">
              <Button className="btn-gradient text-white font-medium px-8 py-3">
                Start Your Project
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
            <Link to="/portfolio">
              <Button variant="outline" className="border-2 border-primary text-primary hover:bg-primary hover:text-white px-8 py-3">
                View Our Work
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;