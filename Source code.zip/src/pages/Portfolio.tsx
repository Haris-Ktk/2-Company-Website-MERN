const Portfolio = () => {
  const projects = [
    {
      title: 'FinTrack – Finance App',
      category: 'Mobile App',
      description: 'A comprehensive personal finance management app with budget tracking, expense monitoring, and investment portfolio management.',
      tech: ['React Native', 'Node.js', 'MongoDB'],
      color: 'from-green-400 to-blue-500',
    },
    {
      title: 'MediCare – Health Management System',
      category: 'Web Application',
      description: 'Healthcare management platform connecting patients with doctors, featuring appointment scheduling and health records.',
      tech: ['React', 'Express.js', 'PostgreSQL'],
      color: 'from-blue-400 to-purple-500',
    },
    {
      title: 'ShopEase – E-commerce Platform',
      category: 'E-commerce',
      description: 'Modern e-commerce solution with advanced inventory management, payment processing, and customer analytics.',
      tech: ['Next.js', 'Stripe', 'Prisma'],
      color: 'from-purple-400 to-pink-500',
    },
    {
      title: 'EduPro – Online Learning Portal',
      category: 'Educational Platform',
      description: 'Comprehensive learning management system with video streaming, progress tracking, and interactive assessments.',
      tech: ['Vue.js', 'Laravel', 'MySQL'],
      color: 'from-orange-400 to-red-500',
    },
    {
      title: 'Foodies – Restaurant Ordering App',
      category: 'Mobile App',
      description: 'Food delivery application with real-time order tracking, payment integration, and restaurant management dashboard.',
      tech: ['Flutter', 'Firebase', 'Google Maps'],
      color: 'from-yellow-400 to-orange-500',
    },
    {
      title: 'AutoGo – Car Rental Website',
      category: 'Web Application',
      description: 'Car rental platform with advanced booking system, fleet management, and customer relationship tools.',
      tech: ['Angular', 'ASP.NET', 'SQL Server'],
      color: 'from-teal-400 to-blue-500',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-heading text-5xl font-bold text-gray-900 mb-6">
            Our Portfolio
          </h1>
          <p className="font-body text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our latest projects and see how we've helped businesses transform their digital presence 
            with innovative solutions and cutting-edge technology.
          </p>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div
                key={project.title}
                className="card-elevated bg-white rounded-2xl overflow-hidden hover-lift animate-fade-in-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Project Image Placeholder with Gradient */}
                <div className={`h-48 bg-gradient-to-br ${project.color} relative overflow-hidden`}>
                  <div className="absolute inset-0 bg-black/20"></div>
                  <div className="absolute bottom-4 left-4">
                    <span className="bg-white/20 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm font-medium">
                      {project.category}
                    </span>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="font-heading text-xl font-semibold text-gray-900 mb-3">
                    {project.title}
                  </h3>
                  
                  <p className="font-body text-gray-600 mb-4 leading-relaxed">
                    {project.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tech.map((tech) => (
                      <span
                        key={tech}
                        className="bg-gray-100 text-gray-700 px-2 py-1 rounded-md text-sm font-body"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                  
                  <button className="text-primary font-medium hover:text-primary-dark transition-colors font-body">
                    View Project →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-gray-900 mb-4">
              Our Impact
            </h2>
            <p className="font-body text-xl text-gray-600 max-w-2xl mx-auto">
              Numbers that showcase our commitment to delivering exceptional results.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '150+', label: 'Projects Completed' },
              { number: '98%', label: 'Client Satisfaction' },
              { number: '50+', label: 'Happy Clients' },
              { number: '24/7', label: 'Support Available' },
            ].map((stat, index) => (
              <div
                key={stat.label}
                className="text-center animate-fade-in-up"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="text-4xl font-heading font-bold text-gradient mb-2">
                  {stat.number}
                </div>
                <div className="font-body text-gray-600">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technologies Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-gray-900 mb-4">
              Technologies We Use
            </h2>
            <p className="font-body text-xl text-gray-600 max-w-2xl mx-auto">
              We work with the latest and most reliable technologies to ensure your project's success.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {[
              'React', 'Vue.js', 'Angular', 'Next.js', 'Node.js', 'Laravel',
              'Python', 'Flutter', 'React Native', 'MongoDB', 'PostgreSQL', 'AWS',
            ].map((tech, index) => (
              <div
                key={tech}
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center border border-gray-100 hover-lift animate-fade-in-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="font-body font-medium text-gray-700">
                  {tech}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-heading text-4xl font-bold text-white mb-6">
            Have a Project in Mind?
          </h2>
          <p className="font-body text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Let's turn your ideas into reality. Contact us today to discuss your next project.
          </p>
          <button className="bg-white text-primary font-medium px-8 py-4 rounded-xl hover:bg-gray-50 transition-colors font-body text-lg hover-lift">
            Start Your Project
          </button>
        </div>
      </section>
    </div>
  );
};

export default Portfolio;